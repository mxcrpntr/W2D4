def no_dupes?(arr)
    non_dupes = arr.uniq
    dupes = []
    count = 0
    non_dupes.each do |el1|
        arr.each do |el2|
            count += 1 if el1 == el2
        end
        dupes << el1 if count > 1
        count = 0
    end
    non_dupes.reject {|el| dupes.include?(el)}
end

def no_consecutive_repeats?(arr)
    (0...arr.length-1).each do |i|
        return false if arr[i] == arr[i+1]
    end
    true
end

def char_indices(str)
    hash = Hash.new {|h,k| h[k] = []}
    str.each_char.with_index do |char,idx|
        hash[char] << idx
    end
    hash
end

def longest_streak(str)
    count = 0
    highest = 0
    streak = ""
    (0...str.length).each do |i|
        (i...str.length).each do |j|
            count += 1 if str[i] == str[j]
            if count >= highest && str[i] == str[j]
                highest = count
                streak = str[i..j]
            end
        end
        count = 0
    end
    streak
end

def prime?(num)
    return false if num < 2
    (2...num).each {|n| return false if num % n == 0}
    true
end

def bi_prime?(num)
    (0...num).each do |i|
        (i...num).each do |j|
            if prime?(i) && prime?(j)
                return true if i * j == num
            end
        end
    end
    false
end

def vigenere_cipher(message, keys)
    alpha = ("a".."z").to_a
    new_message = ""
    message.each_char.with_index do |char,i|
        k = i % keys.length
        alpha_i = (alpha.index(char) + keys[k]) % 26
        new_message += alpha[alpha_i]
    end
    new_message
end

def vowel_rotate(str)
    vowels = "aeiou"
    str_vowels = []
    str.each_char {|char| str_vowels << char if vowels.include?(char)}
    str_vowels.rotate!(-1)
    count = 0
    newstr = ""
    str.each_char do |char|
        if vowels.include?(char)
            newstr += str_vowels[count]
            count += 1
        else
            newstr += char
        end
    end
    newstr
end

class String
    def select(&prc)
        return "" if prc == nil
        array = self.split("")
        array.select! {|el| prc.call(el)}
        array.join("")
    end
    def map!(&prc)
        self.each_char.with_index do |char,i|
            self[i] = prc.call(char,i)
        end
    end
end

def multiply(a, b)
    return 0 if a == 0 || b == 0
    return b if a == 1
    return -b if a == -1
    if a > 1
        b + multiply(a-1,b)
    elsif a < 1
        -b + multiply(a+1,b)
    end
end

def lucas_sequence(n)
    return [] if n == 0
    return [2] if n == 1
    return [2,1] if n == 2
    seq = lucas_sequence(n-1)
    seq << seq[-2] + seq[-1]
    seq
end

def prime_factorization(num)
   return [num] if prime?(num)
   (2...num).each do |n|
        if prime?(n) && num % n == 0
            return [n] + prime_factorization(num / n)
        end
   end
end
# et voila!